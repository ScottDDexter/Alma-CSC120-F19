//********************************************************************
//  TrafficLightControls.java       Java Foundations
//
//  Represents the control panel for the TrafficLight program.
//********************************************************************

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TrafficLightControls extends JPanel
{
	private TrafficLightPanel light;
	// some buttons

	//-----------------------------------------------------------------
	//  Sets up the trafficlight control panel.
	//  Buttons labeled "Stop" "Caution "Go" should cause the red, yellow,
	//  or green "lights" (and only the one light at a time) to come on.
	//-----------------------------------------------------------------
	public TrafficLightControls(TrafficLightPanel lightPanel)
	{
		light = lightPanel;

	}


}

//********************************************************************
//  TrafficLightPanel.java       Java Foundations
//
//  Represents the image for the TrafficLight program.
//********************************************************************

import javax.swing.*;
import java.awt.*;

public class TrafficLightPanel extends JPanel
{
	// need any instance variables to represent the 'state' of the light?

	//-----------------------------------------------------------------
	//  Constructor: Sets up the images and the initial state.
	//-----------------------------------------------------------------
	public TrafficLightPanel()
	{
		setBackground(Color.white);
	

	}

	//-----------------------------------------------------------------
	//  Paints the panel using the appropriate image.
	//-----------------------------------------------------------------
	public void paintComponent(Graphics page)
	{
		super.paintComponent(page);
		paintRedLight(page);
		paintYellowLight(page);
		paintGreenLight(page);
	}
	
	// paint a circle (using current pen color) with center at the specified 
	// height (distance from the top of the panel)
	
	private void paintLight(Graphics page, int height) {
		int panelWidth = getWidth();
		int offset = panelWidth / 4; // so that circle will occupy middle 50% of panel
		
		page.fillOval(offset, height-offset, 2*offset, 2*offset);
	}
	
	
	public void paintRedLight(Graphics page) {
		page.setColor(Color.red);
		paintLight(page,getHeight()/4);	// red light centered at top quarter
		
	}

	public void paintYellowLight(Graphics page) {
		page.setColor(Color.yellow);
		paintLight(page,getHeight()/2);	// red light centered at halfway
	}
	
	
	public void paintGreenLight(Graphics page) {
		page.setColor(Color.green);
		paintLight(page,3*(getHeight()/4));	// red light centered at bottom quarter
	}
	
}

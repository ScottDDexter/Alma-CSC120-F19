//********************************************************************
//  TrafficLight.java       Scott Dexter
//
//  Skeleton for PP w6.7
//********************************************************************

import javax.swing.*;
import java.awt.*;

public class TrafficLight
{
	//-----------------------------------------------------------------
	//  Sets up a frame that displays a light bulb image that can be
	//  turned on and off.
	//-----------------------------------------------------------------
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("Traffic Light");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		TrafficLightPanel light = new TrafficLightPanel();
		TrafficLightControls controls = new TrafficLightControls (light);

		JPanel panel = new JPanel();
		panel.setBackground(Color.black);
		panel.setLayout(new BoxLayout(panel,BoxLayout.X_AXIS));
		panel.add(light);	
		panel.add(controls);
		

		frame.add(panel);
		frame.pack();
		frame.setSize(400,500);
		frame.setVisible(true);
	}
}
